import androidx.annotation.StringRes

data class Question(@StringRes val textReId: Int, val answer: Boolean)